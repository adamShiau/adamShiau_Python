import sys

print('importing mySerial pkg')
sys.path.append('../../')