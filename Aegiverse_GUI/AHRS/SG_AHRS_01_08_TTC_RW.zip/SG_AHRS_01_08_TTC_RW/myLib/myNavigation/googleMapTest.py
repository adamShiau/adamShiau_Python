import gmplot

gm1 = gmplot.GoogleMapPlotter(24.35, 120.66, 13)
gm1.draw('tt.html')