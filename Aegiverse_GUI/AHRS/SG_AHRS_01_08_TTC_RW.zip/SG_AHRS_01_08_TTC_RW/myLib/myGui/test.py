import numpy as np


print(np.sum([1, 2, 3, 4]))