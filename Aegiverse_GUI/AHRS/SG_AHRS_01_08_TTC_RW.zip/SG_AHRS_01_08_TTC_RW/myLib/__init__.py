print('importing myLib pkg')

__version__ = '1.0'

NAME = 'NAME_LIB'

