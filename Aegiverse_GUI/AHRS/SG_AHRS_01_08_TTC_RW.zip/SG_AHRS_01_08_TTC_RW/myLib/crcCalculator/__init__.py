import sys

print('importing crcCalculator pkg')
sys.path.append('../../')
