import sys

print('importing myFilter pkg')
sys.path.append('../../')
