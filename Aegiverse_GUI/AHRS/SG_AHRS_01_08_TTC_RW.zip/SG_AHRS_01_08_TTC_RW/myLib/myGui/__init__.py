import sys

print('importing myGui pkg')
sys.path.append('../../')