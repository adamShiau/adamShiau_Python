__version__ = "1.0.0"
# from EncoderConnector.myEncoderConnector import myEncoderConnector
# from EncoderConnector.myEncoderReader import myEncoderReader